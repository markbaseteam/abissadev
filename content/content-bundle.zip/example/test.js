// Creating a map
const myMap = new Map();

// Adding key-value pairs to the map
myMap.set('name', 'John');
myMap.set('age', 30);
myMap.set('occupation', 'Developer');

// Getting values from the map
const name = myMap.get('name');
const age = myMap.get('age');

// Checking if a key exists in the map
const hasOccupation = myMap.has('occupation');

// Deleting a key-value pair from the map
myMap.delete('age');

// Iterating over the map
for (const [key, value] of myMap) {
  console.log(`${key}: ${value}`);
}

// Clearing all entries from the map
myMap.clear();